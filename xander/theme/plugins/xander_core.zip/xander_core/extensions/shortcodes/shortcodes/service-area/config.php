<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Services Area', 'xander'),
	'description'   => esc_html__('Add Services Area Text', 'xander'),
	'tab'           => esc_html__('Content Elements', 'xander')
);