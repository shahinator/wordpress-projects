<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Get In Touch', 'teadokan'),
	'description'   => esc_html__('Add Get In Touch Text', 'teadokan'),
	'tab'           => esc_html__('Content Elements', 'teadokan')
);