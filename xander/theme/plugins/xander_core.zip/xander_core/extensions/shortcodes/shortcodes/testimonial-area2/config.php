<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Testimonial Area Two', 'xander'),
	'description'   => esc_html__('Add Testimonial Area Two Text', 'xander'),
	'tab'           => esc_html__('Content Elements', 'xander'),
	'popup_size'  => 'large'
);