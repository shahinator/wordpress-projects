<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Call to Action', 'teadokan'),
	'description'   => esc_html__('Add Call to Action Text', 'teadokan'),
	'tab'           => esc_html__('Content Elements', 'teadokan')
);