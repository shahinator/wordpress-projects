<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Recent Work', 'xander' ),
		'description' => __( 'Add a Recent Work', 'xander' ),
		'tab'         => __( 'Content Elements', 'xander' ),
		'popup_size'  => 'large'
	)
);