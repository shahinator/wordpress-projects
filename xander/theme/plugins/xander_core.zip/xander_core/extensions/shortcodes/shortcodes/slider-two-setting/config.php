<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'slider Two', 'xander' ),
	'description' => __( 'Add a image for slider Two show', 'xander' ),
	'tab'         => __( 'Content Elements', 'xander' ),
);