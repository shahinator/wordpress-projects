<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array(
	'page_builder' => array(
		'tab'         => __('Layout Elements', 'teadokan'),
		'title'       => __('Section', 'teadokan'),
		'description' => __('Add a Section', 'teadokan'),
		'popup_size'  => 'medium',
		'type'        => 'section' // WARNING: Do not edit this
	)
);