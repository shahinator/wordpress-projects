<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'slider one', 'xander' ),
	'description' => __( 'Add a image for slider one show', 'xander' ),
	'tab'         => __( 'Content Elements', 'xander' ),
);