<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Map', 'xander' ),
	'description' => __( 'Add a Map', 'xander' ),
	'tab'         => __( 'Content Elements', 'xander' )
);