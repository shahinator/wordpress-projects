<?php if (!defined('FW')) { die('Forbidden'); }

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Home Blog Setting Area', 'xander'),
	'description'   => esc_html__('Add Home Blog Setting Area Text', 'xander'),
	'tab'           => esc_html__('Content Elements', 'xander')
);